To compile and run the program:
1. Under the /project3 directory, type javac .java to compile
2. Under the same directory, type java RunAllcator filePath to run the program with specific test. 
